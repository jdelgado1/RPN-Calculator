package hw4;

import hw4.LinkedStack;
import hw4.Stack;
import hw4.Calc;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalcTest {

}
